Credit-Card-Bruteforcer
=======================

Hacks credit card PAN numbers by using partial Hashes, and a list of random PAN [pins]
It's not fully functional [on purpose!].
