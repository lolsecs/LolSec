import socket
import ast

from electrum import *
from electrum.bitcoin import *
from electrum_gui.qt.qrcodewidget import QRCodeWidget
from electrum_gui.qt import ok_cancel_buttons
from electrum import BasePlugin
from electrum.i18n import _

from PyQt4.QtGui import *
from PyQt4.QtCore import *

import xmlrpclib, ast


PORT = 12345
HOST = 'ecdsa.net'
#HOST = 'localhost'


description = _("This plugin adds two-factor authentication to your wallet.") \
              + _("It uses ecdsa.net and Google Authenticator.")

install_msg = _("This plugin adds two-factor authentication to your wallet. It uses a remote server that co-signs your transactions. To install it, you need to install the Google Authenticator application for Android. Proceed?")


server = xmlrpclib.ServerProxy('http://%s:%d'%(HOST,PORT), allow_none=True)

server_pubkey = "02a6f1262bb454ab79033d02f3b0ae3f6957b073e695442a04fe76378266e4a2f6"
def encrypt(*args):
    message = repr(args)
    return EC_KEY.encrypt_message(message, server_pubkey.decode('hex'))

    


class Plugin(BasePlugin):

    def fullname(self):
        return 'Two Factor Authentication'

    def description(self):
        return description

    def accept_terms_of_use(self):
        return True

    def init(self):
        self.wallet = self.gui.main_window.wallet

    def set_enabled(self, enabled):
        self.wallet.storage.put('use_' + self.name, enabled)

    def is_enabled(self):
        try:
            self.wallet = self.gui.main_window.wallet
        except:
            return False
        return self.is_available() and self.wallet and self.wallet.storage.get('use_'+self.name) is True


    def server_msg(self, secret, *args):
        out = server.msg(encrypt(args))
        ec = bitcoin.EC_KEY(secret.decode('hex'))
        decrypted = ec.decrypt_message(out)
        out = ast.literal_eval(decrypted[0])
        return out



    def sign_transaction(self, tx, password):
        self.wallet = self.gui.main_window.wallet

        if tx.is_complete:
            return

        c2, K2, cK2 = self.wallet.master_public_keys.get("m/2'/")
        auth_code = self.auth_dialog()
        tx_dict = tx.as_dict()

        k1 = self.wallet.get_master_private_key("m/1'/", password)
        signed_tx = self.server_msg(k1, "auth_sign", cK2, tx_dict, auth_code)
        print "received answer", signed_tx

        # the client needs to propagate the transaction
        if not signed_tx:
            gui.main_window.message('Error: Invalid auth code')
        elif signed_tx.get("complete"):
            tx.__init__(signed_tx["hex"])



    def enable(self):
    
        if self.is_enabled():
            self.gui.main_window.show_message('Error: Two-factor authentication is already activated on this wallet')
            return

        if not self.gui.main_window.question(install_msg):
            return

        if not self.accept_terms_of_use():
            return

        self.wallet = self.gui.main_window.wallet

        password = self.gui.main_window.password_dialog() if self.wallet.use_encryption else None

        for i in [0,1]:
            mpk1 = self.wallet.master_public_keys.get("m/1'/")
            mpk2 = self.wallet.master_public_keys.get("m/2'/")
            k1 = self.wallet.get_master_private_key("m/1'/", password)
            k2 = self.wallet.get_master_private_key("m/2'/", password)
            if mpk1 and mpk2 and k1:
                break
            elif i == 0:
                self.wallet.create_master_keys('2of2', password)
            else:
                self.gui.main_window.show_message('Error.')
                return

        c2, K2, cK2 = mpk2
        cK1 = mpk1[2]

        #is_known = server.is_known(cK2)
        if 0: #is_known:
            if k2:
                self.gui.main_window.show_message('The seed will be removed from this wallet file.')
                self.wallet.deseed_root()
                self.wallet.deseed_branch("m/2'/")

            if self.wallet.num_accounts('2of2') == 0:
                self.wallet.create_account('2of2')

            self.gui.main_window.show_message('Welcome back! Two-factor authentication is enabled.')
            self.set_enabled(True)
            return

        # user is not registered
        if not k2:
            self.gui.main_window.show_message('No seed.')
            return


        email = 'user@domain'
        secret = base64.b32encode(bitcoin.sha256(k2)[0:10])
        self.show_qr_auth("otpauth://totp/%s?secret=%s"%('ecdsa.net', secret), "Please scan with Google Authenticator")
        otp = self.auth_dialog()

        if not self.server_msg(k1, "register_user", email, cK1, c2, k2, otp):
            self.gui.main_window.show_message('Incorrect password, aborting')
            return

        # remove seed and k2
        if not self.gui.main_window.question('The seed will be removed from your wallet. Continue?'):
            return
 
        #self.wallet.deseed_root()
        self.wallet.deseed_branch("m/2'/")
        if self.wallet.num_accounts('2of2') == 0:
            self.wallet.create_account('2of2')

        self.gui.main_window.show_message('success: Two-factor authentication is enabled.')
        self.set_enabled(True)
        self.gui.main_window.tabs.setCurrentIndex(2)


    def disable(self):
        if not self.is_enabled():
            self.gui.main_window.show_message( _('Two-factor authentication is not enabled'))
            return

        # todo: 
        # do not remove the accounts, and reseed the wallet.
        self.set_enabled(False)






    def show_qr_auth(self, data, title = "QR code"):
        d = QDialog(self.gui.main_window)
        d.setModal(1)
        d.setWindowTitle("Google Auth")
        d.setMinimumSize(270, 300)
        vbox = QVBoxLayout()

        vbox.addWidget(QLabel("Please scan this QR code with Google Authenticator."))

        qrw = QRCodeWidget(data)
        vbox.addWidget(qrw, 1)
        vbox.addWidget(QLabel(data), 0, Qt.AlignHCenter)
        hbox = QHBoxLayout()
        hbox.addStretch(1)

        b = QPushButton(_("Next"))
        hbox.addWidget(b)
        b.clicked.connect(d.accept)
        b.setDefault(True)
    
        vbox.addLayout(hbox)
        d.setLayout(vbox)
        d.exec_()


    def auth_dialog(self ):
        d = QDialog(self.gui.main_window)
        d.setModal(1)

        pw = QLineEdit()
        vbox = QVBoxLayout()
        msg = _('Please enter your Google Authenticator code')
        vbox.addWidget(QLabel(msg))

        grid = QGridLayout()
        grid.setSpacing(8)
        grid.addWidget(QLabel(_('Code')), 1, 0)
        grid.addWidget(pw, 1, 1)
        vbox.addLayout(grid)

        vbox.addLayout(ok_cancel_buttons(d))
        d.setLayout(vbox)

        if not d.exec_(): return
        return unicode(pw.text())


